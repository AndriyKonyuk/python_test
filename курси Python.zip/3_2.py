import os,re

def directory(wayDir):
    d = os.walk(wayDir)
    for i in d:
        for j in i[2]:
            print(i[0] + '\\' + j)

directory('d:\\Andre')
print('\n\n\n\n')

def dirRecursion(UserWay):
    d = os.listdir(UserWay)
    for i in d:
        if re.findall(r'\.[a-z,A-Z]*', i):
            print(UserWay + '\\' + i)
        else:
            dirRecursion(UserWay + '\\' + i)

dirRecursion('d:\\Andre')