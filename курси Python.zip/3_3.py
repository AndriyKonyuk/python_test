class Tree:
    def __init__(self, value, root=None):
        # left and right child nodes
        self.lchild = None
        self.rchild = None
        # node value
        self.value = value
        # parent element for current node
        self.root = root

    def add(self, value):
        # track current node (level)
        current_node = self
        # track parent node
        last_node = None
        # search the place to insert new node
        while current_node:
            last_node = current_node
            if value > current_node.value:
                current_node = current_node.rchild
            elif value < current_node.value:
                current_node = current_node.lchild
            else:
                # element already presented in tree
                return False
        # create new node and link it with parent
        new_node = Tree(value, last_node)
        if value > last_node.value:
            last_node.rchild = new_node
        else:
            last_node.lchild = new_node
            return True

    def find(self, uvalue):
        while self:
            if self.value == uvalue:
                return True
            elif uvalue > self.value:
                next_node = self.rchild
                return Tree.find(next_node, uvalue)
            else:
                next_node = self.lchild
                return Tree.find(next_node, uvalue)
        else:
            return False

    def height(self):
        if self == None:
            return 0
        else:
            lheight = Tree.height(self.lchild)
            rheight = Tree.height(self.rchild)

            if lheight > rheight:
                return (lheight + 1)
            else:
                return (rheight + 1)


    def printLevel(self, level):
        if self == None:
            return
        if level == 1:
            print("%d " % self.value, end='  ')
        elif level > 1:
            Tree.printLevel(self.lchild, level - 1)
            Tree.printLevel(self.rchild, level - 1)

    def printTree(self):
        h = self.height()
        i = 1
        while (i <= h):
            self.printLevel(i)
            print('\n')
            i += 1


x = Tree(12)
x.add(7)
x.add(5)
x.add(15)
x.add(18)
x.add(14)
x.add(3)
x.add(90)
x.add(76)
x.add(43)
x.add(78)
x.add(45)

print(x.printTree())
