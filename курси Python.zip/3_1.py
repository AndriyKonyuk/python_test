def palindrom(UserString):
    S = ''.join(UserString.split()).lower()
    if S == S[::-1]:
        return True
    else:
        return False

print(palindrom('A b C'))
print(palindrom('A b a B A'))