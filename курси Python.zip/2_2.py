def func(n):
    for i in reversed(range(n+1)):
        print(i)

func(5)